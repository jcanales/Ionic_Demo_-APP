import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liturgias',
  templateUrl: './liturgias.component.html',
  styleUrls: ['./liturgias.component.scss'],
})
export class LiturgiasComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
